# Bina: a local voice AI assistant

Bina runs entirely on your own PC. The language model runs through [Ollama](https://ollama.com/), speech is synthesized locally, and history and memory live in plain files next to the program. It has a chat-style desktop window, two conversation languages (Russian, and English with gentle correction of your mistakes), document and spreadsheet loading, a personal memory, and safe read-only tools.

> The full documentation is in Russian: [README.md](README.md). This file is a shorter English guide.

## Features

- **Local by default.** The model, voice, archive and memory stay on your machine. The internet is used only to download models and for the `/поиск` (web search) command.
- **Desktop window** with a sidebar of past chats, streaming replies, code highlighting and light/dark themes.
- **Two languages.** Russian (Silero voice) and English (Kokoro voice), with a separate model for each language and for code.
- **English correction mode.** Bina replies to what you said, then adds a separate line marked ✎ with the corrected sentence and a short explanation in Russian. Corrections are not read aloud.
- **Personalization without editing code:** assistant name, how to address you, facts about you, your own character prompt.
- **Memory:** saved facts, a conversation archive with search, the topic of the previous chat in the greeting.
- **Files:** txt, md, docx, text-based pdf (ask questions about the content) and csv, xlsx (exact table search without the model).
- **Two audio outputs:** for example, the startup greeting on a speaker and the conversation on headphones.
- **Read-only tools** (`/система`, `/папки`, `/файлы`) and a confirmed multi-step task planner (`/задача`, `/выполни`).

## Requirements

- Windows 11 (other systems were not tested), Python 3.12 recommended (3.12 and 3.13 tested).
- [Ollama](https://ollama.com/download) running locally.
- An NVIDIA GPU with 8 GB or more is recommended for 7-8B models (16 GB for 12-14B models). CPU-only works but is slow.
- About 15 GB of free disk space.

## Installation

1. Install Python 3.12 and Ollama.
2. Pull models:
   ```powershell
   ollama pull qwen2.5:7b-instruct     # Russian mode
   ollama pull llama3.1:8b             # English mode
   ollama pull qwen2.5-coder:7b        # code mode (/coder)
   ```
   You can pick any other Ollama models later in **Settings** (one per language and one for code).
3. Install dependencies:
   ```powershell
   py -3.12 -m pip install -r requirements.txt
   py -3.12 -m pip install -r requirements-english.txt    # English voice (Kokoro)
   ```
   Kokoro may also need [espeak-ng](https://github.com/espeak-ng/espeak-ng/releases) on Windows.
4. Run `start_bina.bat` (or `py -3.12 bina.py`). The Silero voice is downloaded on the first run.

If `pywebview` is missing, the interface opens in your browser instead of a separate window.

## Usage

- **Settings (⚙):** language, voices, models, corrections, audio devices, personalization.
- **Attach a file** with the paperclip or by dragging it into the window.
- Type `/помощь` to see all commands.

| Command | Description |
|---|---|
| `/поиск <query>` | web search, answer from the results |
| `/вспомни <topic>`, `/контекст <topic>` | use memory, profile and archive |
| `/история [N]`, `/найди <word>` | show or search the archive |
| `/память`, `/запомни <text>`, `/забудь <n>` | manage saved facts |
| `/итоги`, `/принять 1 3` | the model proposes facts from the session, you choose |
| `/забудь последние <N>`, `/очистить история`, `/подтверди` | delete archive entries (with confirmation) |
| `/тема` | suggest a conversation topic |
| `/новый` | new chat |
| `/язык ru\|en` | switch language |
| `/исправления вкл\|выкл` | correction mode (English only) |
| `/голос <name>` | choose a voice (Russian: aidar, baya, kseniya, xenia, eugene; English: af_heart, af_bella, af_nicole, af_sarah, af_sky, bf_emma, bf_isabella, am_michael, bm_george) |
| `/coder`, `/бина` | code mode and normal mode |
| `/таблица`, `/ищи <value>`, `/ищи Column: value`, `/закрыть` | work with an attached table or file |
| `/система`, `/папки`, `/файлы <name>` | read-only tools |
| `/задача <goal>`, `/выполни`, `/отмена-задачи` | task plan with explicit confirmation |

## Personalization

Open **Settings → Personalization** or edit `personalization.json` (see `personalization.example.json`): assistant name, how to address you, facts about you (one per line), and an optional custom character for each language. Rules about language, answer format and safety are kept whatever character you choose.

## Privacy and security

- Conversations, memory, profile and settings are stored as **plain text** next to the program. These files are listed in `.gitignore` so they are not published by accident.
- The only network traffic: model downloads (Ollama, `torch.hub` for Silero, Hugging Face for Kokoro) and `/поиск` queries sent to DuckDuckGo through the `ddgs` library.
- The web server listens on `127.0.0.1` only.
- Tools are **read-only** and pass through a permission dispatcher (`bts_dispatcher.py`, `bts_permissions.json`); file search is limited to the folders in `bina_tools_roots.txt`. A task plan runs only after you type `/выполни`.
- Small models can be misled by text inside loaded documents or web results. Do not load untrusted files.

## Troubleshooting

| Symptom | What to do |
|---|---|
| No answer or "model error" | Is Ollama running (`ollama list`)? Is the selected model pulled? |
| Very slow answers | `ollama ps` should show `100% GPU`; otherwise the model does not fit in VRAM |
| No sound | Check the output device in Settings and use the "Проверить" (test) button |
| English is silent | Install `requirements-english.txt` (and espeak-ng if needed), then restart |
| `.xlsx` / `.pdf` fail | `pip install openpyxl pypdf` |

## Development

```powershell
py -3.12 -m unittest discover -s tests -v
```

The tests need neither Ollama nor a GPU.

## License and notes

- Add a `LICENSE` file of your choice before publishing.
- The components used (Ollama, the models, Silero, Kokoro and the libraries in `requirements.txt`) have their own licenses; check their terms, especially for commercial use.
- Bina is generated by a language model and can be wrong; verify anything important.
