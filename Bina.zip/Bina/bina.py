"""
Бина: окно приложения. Запуск: py -3.12 bina.py
Требуется: pip install fastapi uvicorn pywebview
Для файлов (по желанию): pip install pypdf openpyxl
"""
import json
import os
import socket
import threading
import time
import webbrowser
from pathlib import Path
from typing import Optional

import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, StreamingResponse
from pydantic import BaseModel
from starlette.concurrency import run_in_threadpool

import engine

BASE = Path(__file__).parent
MAX_UPLOAD = 30 * 1024 * 1024
app = FastAPI()
lock = threading.Lock()  # один запрос к модели за раз
bina = None


class Msg(BaseModel):
    text: str


class Settings(BaseModel):
    voice: str = ""
    main: str = ""
    greet: str = ""
    lang: str = ""
    voice_en: str = ""
    model_ru: str = ""
    model_en: str = ""
    model_coder: str = ""
    corrections: Optional[bool] = None


@app.get("/")
def index():
    return HTMLResponse((BASE / "index.html").read_text(encoding="utf-8"))


@app.get("/api/start")
def start():
    with lock:
        return {"text": bina.start()}


@app.post("/api/chat")
def chat(msg: Msg):
    def gen():
        with lock:
            try:
                for ev in bina.handle(msg.text):
                    yield json.dumps(ev, ensure_ascii=False) + "\n"
            except Exception as e:
                yield json.dumps({"t": "note", "v": f"[ошибка: {e}]"}, ensure_ascii=False) + "\n"
    return StreamingResponse(gen(), media_type="application/x-ndjson")


@app.get("/api/sessions")
def sessions():
    return {"items": engine.list_sessions()}


@app.get("/api/session/{sid}")
def session(sid: str):
    return {"items": engine.session_messages(sid)}


@app.post("/api/new")
def new_chat():
    with lock:
        bina.new_chat()
    return {"ok": True}


@app.post("/api/file")
async def upload(request: Request, name: str):
    data = await request.body()
    if len(data) > MAX_UPLOAD:
        return {"note": "[файл больше 30 МБ, не загружаю]", "chip": None}

    def work():
        with lock:
            return bina.attach_file(name, data)

    note, chip = await run_in_threadpool(work)
    return {"note": note, "chip": chip}


@app.post("/api/close")
def close_file():
    with lock:
        note = bina.run_command("/закрыть", "")
    return {"note": note}


@app.get("/api/settings")
def get_settings():
    return engine.get_settings()


@app.post("/api/settings")
def set_settings(s: Settings):
    old_lang = engine.LANG
    engine.set_settings(s.voice, s.main, s.greet, s.lang, s.voice_en,
                        s.model_ru, s.model_en, s.model_coder, s.corrections)
    if engine.LANG != old_lang:  # другой язык: контекст прежнего разговора сбрасывается (архив остаётся)
        bina.history, bina.since_q = [], 0
    return engine.get_settings()


class Personal(BaseModel):
    name: str = ""
    user_name: str = ""
    about: str = ""
    persona_ru: str = ""
    persona_en: str = ""


@app.get("/api/personal")
def get_personal():
    return engine.get_personal()


@app.post("/api/personal")
def set_personal(p: Personal):
    engine.set_personal({"name": p.name, "user_name": p.user_name, "about": p.about,
                         "persona_ru": p.persona_ru, "persona_en": p.persona_en})
    return engine.get_personal()


@app.post("/api/test")
def test_sound(which: str = "main"):
    engine.test_sound(which)
    return {"ok": True}


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def main():
    global bina
    engine.init_audio()
    bina = engine.Bina()

    port = free_port()
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning"))
    threading.Thread(target=server.run, daemon=True).start()
    while not server.started:
        time.sleep(0.05)
    url = f"http://127.0.0.1:{port}/"

    try:
        import webview
        webview.create_window("Бина", url, width=1100, height=780, min_size=(520, 560))
        webview.start()
    except Exception as e:
        print(f"[окно не открылось ({e}), открываю в браузере; для выхода закройте этот терминал]")
        webbrowser.open(url)
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass
    engine.shutdown_audio()
    os._exit(0)


if __name__ == "__main__":
    main()
