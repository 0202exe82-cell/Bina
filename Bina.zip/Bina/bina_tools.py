"""Безопасные встроенные инструменты Бины (BTS starter pack).

Инструменты только читают сведения о системе и ищут файлы по имени.
Никакие найденные .py/.bat/.exe не запускаются.
"""
from __future__ import annotations
import os
import platform
import shutil
from pathlib import Path

BASE = Path(__file__).resolve().parent
HOME = Path.home().resolve()

def allowed_roots() -> list[Path]:
    """Разрешённые области поиска. Можно настроить в bina_tools_roots.txt.

    По умолчанию: папка проекта и стандартные папки пользователя, если существуют.
    Не добавляем весь диск C: автоматически.
    """
    cfg = BASE / "bina_tools_roots.txt"
    candidates = []
    if cfg.exists():
        for line in cfg.read_text(encoding="utf-8").splitlines():
            line = line.strip().strip('"')
            if line and not line.startswith("#"):
                p = Path(os.path.expandvars(os.path.expanduser(line)))
                if p.exists() and p.is_dir():
                    candidates.append(p.resolve())
    if not candidates:
        candidates = [BASE, HOME / "Desktop", HOME / "Documents", HOME / "Downloads"]
    roots=[]
    for p in candidates:
        try:
            rp=p.resolve()
            if rp.is_dir() and rp not in roots:
                roots.append(rp)
        except OSError:
            pass
    return roots

def system_info() -> str:
    """Возвращает базовую информацию об ОС и диске без сторонних библиотек."""
    lines=[
        f"ОС: {platform.system()} {platform.release()}",
        f"Версия Python: {platform.python_version()}",
        f"Архитектура: {platform.machine()}",
        f"Имя компьютера: {platform.node()}",
    ]
    try:
        usage=shutil.disk_usage(BASE)
        gib=1024**3
        lines.append(f"Диск с проектом: свободно {usage.free/gib:.1f} ГиБ из {usage.total/gib:.1f} ГиБ")
    except OSError:
        lines.append("Данные о диске недоступны.")
    roots=allowed_roots()
    lines.append("Разрешённые папки поиска:")
    lines.extend(f"  - {p}" for p in roots)
    return "\n".join(lines)

def file_search(query: str, max_results: int = 20) -> str:
    """Ищет по имени файла/папки в разрешённых каталогах; ничего не меняет."""
    query=query.strip().casefold()
    if not query:
        return "Укажи часть имени файла. Пример: /файлы bina.py"
    roots=allowed_roots()
    if not roots:
        return "Нет доступных папок для поиска. Настрой bina_tools_roots.txt."
    matches=[]
    scanned=0
    scan_limit=15000
    skip={"$recycle.bin", "system volume information", "node_modules", ".git", "__pycache__"}
    for root in roots:
        for current, dirs, files in os.walk(root, topdown=True, followlinks=False):
            dirs[:]=[d for d in dirs if d.casefold() not in skip and not d.startswith(".") ]
            # Do not descend into symlink directories.
            dirs[:]=[d for d in dirs if not (Path(current)/d).is_symlink()]
            for name in files + dirs:
                scanned += 1
                if query in name.casefold():
                    p=Path(current)/name
                    try:
                        if p.resolve().is_relative_to(root):
                            matches.append(str(p))
                    except (OSError, ValueError):
                        continue
                    if len(matches)>=max_results:
                        break
                if scanned>=scan_limit or len(matches)>=max_results:
                    break
            if scanned>=scan_limit or len(matches)>=max_results:
                break
        if scanned>=scan_limit or len(matches)>=max_results:
            break
    if not matches:
        suffix=" (достигнут лимит обхода)" if scanned>=scan_limit else ""
        return f"Ничего не найдено. Проверено объектов: {scanned}{suffix}."
    lines=[f"Найдено: {len(matches)} (проверено объектов: {scanned})."]
    lines.extend(f"{i}. {p}" for i,p in enumerate(matches,1))
    if scanned>=scan_limit:
        lines.append("Поиск остановлен на защитном лимите в 15000 объектов.")
    return "\n".join(lines)
