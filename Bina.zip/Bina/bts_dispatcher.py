"""Единый диспетчер безопасных инструментов BTS.

Все вызовы проходят через проверку схемы аргументов и локальные разрешения.
По умолчанию зарегистрированы только операции чтения. Исполнение команд,
изменение и удаление файлов намеренно не реализованы.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import bina_tools

BASE = Path(__file__).resolve().parent
PERMISSIONS_FILE = BASE / "bts_permissions.json"


@dataclass(frozen=True)
class Tool:
    name: str
    description: str
    schema: dict[str, dict[str, Any]]
    handler: Callable[..., str]
    permission: str = "read"


def _search_files(query: str, max_results: int = 20) -> str:
    return bina_tools.file_search(query, max_results=max_results)


def _list_roots() -> str:
    roots = bina_tools.allowed_roots()
    return "\n".join(str(p) for p in roots) if roots else "[нет разрешённых папок]"


TOOLS: dict[str, Tool] = {
    "system.info": Tool(
        name="system.info",
        description="Получить базовые сведения об ОС, Python и свободном месте на диске.",
        schema={},
        handler=bina_tools.system_info,
    ),
    "files.roots": Tool(
        name="files.roots",
        description="Показать разрешённые корневые папки для поиска.",
        schema={},
        handler=_list_roots,
    ),
    "files.search": Tool(
        name="files.search",
        description="Найти файлы и папки по части имени в разрешённых корнях; только чтение.",
        schema={
            "query": {"type": "string", "required": True, "max_length": 200},
            "max_results": {"type": "integer", "required": False, "minimum": 1, "maximum": 50},
        },
        handler=_search_files,
    ),
}


def _permissions() -> dict[str, Any]:
    """Безопасные значения по умолчанию; ошибочная конфигурация ничего не разрешает."""
    defaults = {name: {"enabled": True, "permission": "read"} for name in TOOLS}
    if not PERMISSIONS_FILE.exists():
        return defaults
    try:
        data = json.loads(PERMISSIONS_FILE.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or not isinstance(data.get("tools", {}), dict):
            return {name: {"enabled": False, "permission": "read"} for name in TOOLS}
        configured = data.get("tools", {})
        result = {}
        for name in TOOLS:
            entry = configured.get(name, {})
            if not isinstance(entry, dict):
                result[name] = {"enabled": False, "permission": "deny"}
                continue
            result[name] = {
                "enabled": entry.get("enabled") is True,
                "permission": entry.get("permission", "read"),
            }
        return result
    except (OSError, ValueError, TypeError):
        return {name: {"enabled": False, "permission": "read"} for name in TOOLS}


def list_tools() -> list[dict[str, Any]]:
    """Возвращает описание только разрешённых инструментов, без обработчиков."""
    permissions = _permissions()
    result = []
    for name, tool in TOOLS.items():
        policy = permissions.get(name, {})
        if policy.get("enabled") is True and policy.get("permission") == tool.permission:
            result.append({"name": name, "description": tool.description, "schema": tool.schema,
                           "permission": tool.permission})
    return result


def _validate(tool: Tool, arguments: Any) -> dict[str, Any]:
    if not isinstance(arguments, dict):
        raise ValueError("Аргументы инструмента должны быть объектом.")
    unknown = set(arguments) - set(tool.schema)
    if unknown:
        raise ValueError("Переданы неизвестные аргументы: " + ", ".join(sorted(unknown)))
    cleaned: dict[str, Any] = {}
    for key, spec in tool.schema.items():
        if key not in arguments:
            if spec.get("required"):
                raise ValueError(f"Не указан обязательный аргумент: {key}")
            continue
        value = arguments[key]
        expected = spec["type"]
        if expected == "string":
            if not isinstance(value, str):
                raise ValueError(f"Аргумент {key} должен быть строкой.")
            value = value.strip()
            if not value:
                raise ValueError(f"Аргумент {key} не должен быть пустым.")
            if len(value) > spec.get("max_length", 1000):
                raise ValueError(f"Аргумент {key} слишком длинный.")
        elif expected == "integer":
            if isinstance(value, bool) or not isinstance(value, int):
                raise ValueError(f"Аргумент {key} должен быть целым числом.")
            if value < spec.get("minimum", value) or value > spec.get("maximum", value):
                raise ValueError(f"Аргумент {key} вне допустимого диапазона.")
        cleaned[key] = value
    return cleaned


def dispatch(name: str, arguments: Any | None = None) -> str:
    """Вызвать разрешённый инструмент, валидируя имя, права и аргументы."""
    if not isinstance(name, str) or name not in TOOLS:
        return "[ошибка BTS: неизвестный инструмент]"
    tool = TOOLS[name]
    policy = _permissions().get(name, {})
    if policy.get("enabled") is not True or policy.get("permission") != tool.permission:
        return "[доступ к инструменту запрещён настройками BTS]"
    try:
        validated = _validate(tool, {} if arguments is None else arguments)
        return str(tool.handler(**validated))
    except ValueError as exc:
        return f"[некорректные аргументы BTS: {exc}]"
    except Exception:
        # Не раскрываем пользователю внутренние детали исключения.
        return "[ошибка BTS: инструмент не смог выполнить операцию; подробности доступны в журнале приложения]"
