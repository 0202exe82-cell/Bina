"""Поиск по локальной памяти и архиву Бины; только стандартная библиотека."""
import re
from datetime import datetime

STOPWORDS = {
    "это", "как", "что", "для", "или", "при", "про", "мне", "меня", "мой", "моя", "мои",
    "тебя", "тебе", "этот", "эта", "эти", "тот", "там", "тут", "был", "была", "были",
    "есть", "будет", "будут", "чтобы", "если", "только", "можно", "нужно", "очень",
    "когда", "где", "почему", "зачем", "какой", "какая", "какие", "который", "которые",
    "пожалуйста", "вспомни", "найди", "контекст", "помнишь", "разговор", "разговора",
}


def _norm(text):
    return (text or "").lower().replace("ё", "е")


def _terms(text):
    return [w for w in re.findall(r"[\w-]+", _norm(text)) if len(w) > 2 and w not in STOPWORDS]


def search_context(query, history, facts=(), profile="", limit=6):
    """Возвращает (контекст для модели, краткий отчёт). Источники не изменяются."""
    terms = _terms(query)
    if not terms:
        return "", "[укажи тему или несколько ключевых слов]"

    scored = []
    for i, row in enumerate(history):
        text = str(row.get("text", ""))
        normalized = _norm(text)
        score = sum(3 if term in normalized else 0 for term in terms)
        # Точное совпадение фразы важнее отдельных слов.
        if _norm(query).strip() and _norm(query).strip() in normalized:
            score += 5
        if score:
            ts = str(row.get("ts", ""))
            scored.append((score, i, f"[{ts[:10] or 'дата неизвестна'}, {'пользователь' if row.get('role') == 'user' else 'Бина'}]: {text[:500]}"))
    scored.sort(key=lambda item: (-item[0], -item[1]))
    history_hits = [x[2] for x in sorted(scored[:limit], key=lambda item: item[1])]

    memory_hits = []
    for fact in facts:
        text = str(fact).strip()
        normalized = _norm(text)
        score = sum(3 if term in normalized else 0 for term in terms)
        if score:
            memory_hits.append((score, text))
    memory_hits.sort(key=lambda x: -x[0])

    profile_hits = []
    for line in (profile or "").splitlines():
        line = line.strip()
        if line and any(term in _norm(line) for term in terms):
            profile_hits.append(line)

    sections = []
    if memory_hits:
        sections.append("Сохранённые факты:\n" + "\n".join(f"- {x[1]}" for x in memory_hits[:limit]))
    if profile_hits:
        sections.append("Профиль:\n" + "\n".join(f"- {x}" for x in profile_hits[:limit]))
    if history_hits:
        sections.append("Архив разговоров:\n" + "\n".join(history_hits))
    if not sections:
        return "", "[в памяти и архиве ничего подходящего не нашлось]"
    context = "\n\n".join(sections)
    preview = []
    if memory_hits:
        preview.extend(f"Память: {x[1]}" for x in memory_hits[:3])
    if profile_hits:
        preview.extend(f"Профиль: {x}" for x in profile_hits[:3])
    if history_hits:
        preview.extend(history_hits[:4])
    return context, "Нашла подходящие сведения:\n" + "\n".join(preview)
