"""Заглушки тяжёлых библиотек (torch, sounddevice, ollama), чтобы тестировать engine без GPU и Ollama."""
import sys
import types
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


class _Arr:
    def numpy(self):
        return self


for _name in ("torch", "sounddevice", "ollama"):
    sys.modules.setdefault(_name, types.ModuleType(_name))
if not hasattr(sys.modules["torch"], "hub"):
    sys.modules["torch"].hub = types.SimpleNamespace(
        load=lambda **k: (types.SimpleNamespace(apply_tts=lambda **kw: _Arr()), ""))
if not hasattr(sys.modules["ollama"], "chat"):
    sys.modules["ollama"].chat = lambda **k: iter(())
