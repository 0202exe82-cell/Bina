"""Базовые проверки безопасных инструментов Бины. Запуск: py -m unittest discover -s tests -v"""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import bina_tools


class BinaToolsTests(unittest.TestCase):
    def test_empty_search_query_is_rejected(self):
        self.assertIn("Укажи часть имени", bina_tools.file_search("   "))

    def test_search_finds_name_in_allowed_root(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "project-settings.json").write_text("{}", encoding="utf-8")
            with patch.object(bina_tools, "allowed_roots", return_value=[root]):
                result = bina_tools.file_search("settings")
            self.assertIn("project-settings.json", result)
            self.assertIn("Найдено: 1", result)

    def test_search_does_not_follow_symlink_directory(self):
        with tempfile.TemporaryDirectory() as tmp, tempfile.TemporaryDirectory() as outside:
            root = Path(tmp)
            outside_root = Path(outside)
            (outside_root / "secret-target.txt").write_text("secret", encoding="utf-8")
            link = root / "outside-link"
            try:
                link.symlink_to(outside_root, target_is_directory=True)
            except (OSError, NotImplementedError):
                self.skipTest("Symlink creation is unavailable on this platform")
            with patch.object(bina_tools, "allowed_roots", return_value=[root]):
                result = bina_tools.file_search("secret-target")
            self.assertIn("Ничего не найдено", result)

    def test_system_info_returns_basic_diagnostics(self):
        result = bina_tools.system_info()
        self.assertIn("ОС:", result)
        self.assertIn("Версия Python:", result)
        self.assertIn("Разрешённые папки поиска:", result)


if __name__ == "__main__":
    unittest.main()
