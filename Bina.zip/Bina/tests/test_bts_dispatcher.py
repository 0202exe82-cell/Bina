"""Проверки единого диспетчера BTS. Запуск: py -m unittest discover -s tests -v"""
import json
import unittest
from unittest.mock import patch

import bts_dispatcher


class BTSDispatcherTests(unittest.TestCase):
    def test_only_registered_tools_are_listed(self):
        names = {tool["name"] for tool in bts_dispatcher.list_tools()}
        self.assertEqual(names, {"system.info", "files.roots", "files.search"})

    def test_unknown_tool_is_rejected(self):
        self.assertIn("неизвестный инструмент", bts_dispatcher.dispatch("system.exec"))

    def test_search_requires_query(self):
        result = bts_dispatcher.dispatch("files.search", {})
        self.assertIn("обязательный аргумент", result)

    def test_search_rejects_unknown_arguments(self):
        result = bts_dispatcher.dispatch("files.search", {"query": "report", "path": "/"})
        self.assertIn("неизвестные аргументы", result)

    def test_search_rejects_invalid_limit(self):
        result = bts_dispatcher.dispatch("files.search", {"query": "report", "max_results": 500})
        self.assertIn("вне допустимого диапазона", result)

    def test_disabled_tool_is_denied(self):
        config = {"tools": {"files.search": {"enabled": False, "permission": "read"}}}
        with patch.object(bts_dispatcher, "PERMISSIONS_FILE") as cfg:
            cfg.exists.return_value = True
            cfg.read_text.return_value = json.dumps(config)
            result = bts_dispatcher.dispatch("files.search", {"query": "report"})
        self.assertIn("доступ к инструменту запрещён", result)

    def test_broken_permissions_fail_closed(self):
        with patch.object(bts_dispatcher, "PERMISSIONS_FILE") as cfg:
            cfg.exists.return_value = True
            cfg.read_text.side_effect = OSError("secret internal detail")
            result = bts_dispatcher.dispatch("system.info")
        self.assertIn("доступ к инструменту запрещён", result)
        self.assertNotIn("secret internal detail", result)


if __name__ == "__main__":
    unittest.main()
