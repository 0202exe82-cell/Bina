"""Проверки английского режима: язык, подсказки, исправления, озвучка, настройки. Тяжёлые библиотеки заменены заглушками."""
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


class _Arr:
    def numpy(self):
        return self


for name, mod in (("torch", types.ModuleType("torch")), ("sounddevice", types.ModuleType("sounddevice")),
                  ("ollama", types.ModuleType("ollama"))):
    sys.modules.setdefault(name, mod)
sys.modules["torch"].hub = types.SimpleNamespace(load=lambda **k: (types.SimpleNamespace(apply_tts=lambda **kw: _Arr()), ""))
sys.modules["ollama"].chat = lambda **k: iter(())

import engine  # noqa: E402


def fake_chat(*tokens):
    return lambda **kw: iter([{"message": {"content": t}} for t in tokens])


class LanguageModeTests(unittest.TestCase):
    def setUp(self):
        self.saved = (engine.LANG, engine.CORRECTIONS, dict(engine.MODELS), engine.SPEAKER, engine.SPEAKER_EN,
                      engine.SETTINGS_FILE, engine.HISTORY_FILE, engine.TOPIC_FILE, engine.SUGGESTED_FILE,
                      engine.MEMORY_FILE, engine.PROFILE_FILE)
        self.tmp = Path(tempfile.mkdtemp())
        engine.SETTINGS_FILE = self.tmp / "settings.json"
        engine.HISTORY_FILE = self.tmp / "history.jsonl"
        engine.TOPIC_FILE = self.tmp / "topic.json"
        engine.SUGGESTED_FILE = self.tmp / "suggested.json"
        engine.MEMORY_FILE = self.tmp / "memory.txt"
        engine.PROFILE_FILE = self.tmp / "profile.txt"
        engine.LANG, engine.CORRECTIONS = "ru", True

    def tearDown(self):
        (engine.LANG, engine.CORRECTIONS, models, engine.SPEAKER, engine.SPEAKER_EN, engine.SETTINGS_FILE,
         engine.HISTORY_FILE, engine.TOPIC_FILE, engine.SUGGESTED_FILE, engine.MEMORY_FILE,
         engine.PROFILE_FILE) = self.saved
        engine.MODELS.clear()
        engine.MODELS.update(models)

    # --- разделение ответа и исправлений ---
    def test_splitter_marker_split_across_tokens(self):
        sp = engine.FixSplitter()
        out = "".join(sp.feed(t) for t in ["Nice! ", "[[FI", "X]] I went", " home. Я пошёл."])
        out += sp.finish()
        self.assertEqual(out, "Nice! ")
        self.assertEqual(sp.fix.strip(), "I went home. Я пошёл.")

    def test_splitter_without_marker_keeps_everything(self):
        sp = engine.FixSplitter()
        out = "".join(sp.feed(t) for t in ["Hello [", "there", "]!"]) + sp.finish()
        self.assertEqual(out, "Hello [there]!")
        self.assertEqual(sp.fix, "")

    def test_splitter_holds_partial_marker_at_end(self):
        sp = engine.FixSplitter()
        self.assertEqual(sp.feed("Hi [["), "Hi ")
        self.assertEqual(sp.finish(), "[[")

    # --- озвучка не читает исправления ---
    def test_stream_reply_does_not_speak_fix_block(self):
        spoken = []
        with patch.object(engine, "say", lambda text, greeting=False: spoken.append(text)), \
             patch.object(engine.ollama, "chat", fake_chat("Great story. ", "How was it? [[F", "IX]] I went. Я пошёл.")):
            list(engine.stream_reply("m", []))
        joined = " ".join(spoken)
        self.assertIn("Great story.", joined)
        self.assertNotIn("FIX", joined)
        self.assertNotIn("Я пошёл", joined)

    # --- handle: исправления попадают в заметку, а не в историю ---
    def test_handle_splits_correction_into_note(self):
        engine.set_lang("en")
        b = engine.Bina()
        with patch.object(engine, "say", lambda *a, **k: None), \
             patch.object(engine.ollama, "chat", fake_chat("Sounds fun! ", "[[FIX]] I went to the park. Предлог to.")):
            events = list(b.handle("I go to park yesterday"))
        text = "".join(e["v"] for e in events if e["t"] == "token")
        notes = [e["v"] for e in events if e["t"] == "note"]
        self.assertEqual(text.strip(), "Sounds fun!")
        self.assertTrue(any(n.startswith("✎") and "I went to the park" in n for n in notes))
        self.assertNotIn("FIX", b.history[-1]["content"])

    def test_correction_hint_only_in_english_plain_messages(self):
        self.assertNotIn(engine.FIX_MARK, engine.build_hint(0, False, True))  # русский режим
        engine.set_lang("en")
        self.assertIn(engine.FIX_MARK, engine.build_hint(0, False, True))
        self.assertNotIn(engine.FIX_MARK, engine.build_hint(0, False, False))  # команда
        engine.set_corrections(False)
        self.assertNotIn(engine.FIX_MARK, engine.build_hint(0, False, True))

    # --- язык ---
    def test_system_prompt_follows_language(self):
        b = engine.Bina()
        self.assertIn("Ты — Бина", b.system_prompt())
        engine.set_lang("en")
        self.assertIn("You are Bina", b.system_prompt())
        b.coder = True
        self.assertIn("programming assistant", b.system_prompt())

    def test_greeting_and_commands_switch_language(self):
        b = engine.Bina()
        list(b.handle("/язык en"))
        self.assertEqual(engine.LANG, "en")
        self.assertRegex(engine.greeting_text(""), r"^[A-Za-z',. ?!]+$")
        list(b.handle("/язык ru"))
        self.assertEqual(engine.LANG, "ru")

    def test_topic_request_detected_in_english(self):
        self.assertTrue(engine.TOPIC_ASK_EN.search("can you suggest a topic for us?"))
        self.assertTrue(engine.TOPIC_ASK_EN.search("what should we talk about"))
        self.assertFalse(engine.TOPIC_ASK_EN.search("I like the topic of space"))

    def test_voice_command_accepts_both_languages(self):
        self.assertTrue(engine.apply_voice("bf_emma"))
        self.assertEqual(engine.SPEAKER_EN, "bf_emma")
        self.assertTrue(engine.apply_voice("baya"))
        self.assertEqual(engine.SPEAKER, "baya")
        self.assertFalse(engine.apply_voice("nobody"))

    # --- настройки ---
    def test_settings_roundtrip(self):
        engine.set_settings(voice="aidar", main="Колонка", greet="", lang="en", voice_en="am_michael",
                            model_ru="a:1", model_en="llama3.1:8b", model_coder="c:1", corrections=False)
        engine.LANG, engine.CORRECTIONS = "ru", True
        engine.MODELS.update({"ru": "x", "en": "x", "coder": "x"})
        engine.load_settings()
        self.assertEqual((engine.LANG, engine.CORRECTIONS, engine.SPEAKER, engine.SPEAKER_EN),
                         ("en", False, "aidar", "am_michael"))
        self.assertEqual(engine.MODELS, {"ru": "a:1", "en": "llama3.1:8b", "coder": "c:1"})
        self.assertEqual(engine.active_model(), "llama3.1:8b")
        self.assertEqual(engine.active_model(True), "c:1")

    def test_old_settings_file_without_new_keys_still_loads(self):
        engine.save_json(engine.SETTINGS_FILE, {"voice": "baya", "dev_main": "X"})
        engine.load_settings()
        self.assertEqual((engine.LANG, engine.CORRECTIONS, engine.SPEAKER), ("ru", True, "baya"))

    def test_installed_models_handles_both_response_shapes(self):
        with patch.object(engine.ollama, "list", create=True, return_value={"models": [{"name": "a:1"}, {"model": "b:2"}]}):
            self.assertEqual(engine.installed_models(), ["a:1", "b:2"])
        obj = types.SimpleNamespace(models=[types.SimpleNamespace(model="c:3")])
        with patch.object(engine.ollama, "list", create=True, return_value=obj):
            self.assertEqual(engine.installed_models(), ["c:3"])
        with patch.object(engine.ollama, "list", create=True, side_effect=RuntimeError("down")):
            self.assertEqual(engine.installed_models(), [])

    # --- английская озвучка без Kokoro не ломает работу ---
    def test_synth_en_without_kokoro_returns_none_once(self):
        engine._kokoro.clear()
        engine._kokoro_failed = False
        with patch.dict(sys.modules, {"kokoro": None}):
            self.assertIsNone(engine.synth_en("Hello there"))
        self.assertTrue(engine._kokoro_failed)
        self.assertIsNone(engine.synth_en("Again"))
        engine._kokoro_failed = False


if __name__ == "__main__":
    unittest.main()
