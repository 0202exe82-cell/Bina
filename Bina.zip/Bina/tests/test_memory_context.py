import unittest
from memory_context import search_context


class MemoryContextTests(unittest.TestCase):
    def setUp(self):
        self.history = [
            {"ts": "2026-10-20T10:00:00", "session": "a", "role": "user", "text": "Мы обсуждали проект Bina и локальную память."},
            {"ts": "2026-10-20T10:01:00", "session": "a", "role": "assistant", "text": "Для проекта Bina добавим поиск по архиву."},
            {"ts": "2026-10-19T10:00:00", "session": "b", "role": "user", "text": "Рецепт яблочного пирога."},
        ]

    def test_search_finds_relevant_history_and_fact(self):
        context, shown = search_context("проект Bina", self.history,
                                       ["Пользователь разрабатывает проект Bina"], "Любит короткие ответы")
        self.assertIn("проект Bina", context)
        self.assertIn("Сохранённые факты", context)
        self.assertIn("Нашла подходящие сведения", shown)

    def test_unrelated_query_returns_no_results(self):
        context, shown = search_context("космический корабль", self.history, [], "")
        self.assertEqual(context, "")
        self.assertIn("ничего подходящего", shown)

    def test_empty_query_is_rejected(self):
        context, shown = search_context("что и как", self.history)
        self.assertEqual(context, "")
        self.assertIn("укажи тему", shown)

    def test_profile_match_is_included(self):
        context, _ = search_context("короткие ответы", [], [], "Предпочитает короткие ответы")
        self.assertIn("Профиль", context)
        self.assertIn("короткие ответы", context)


if __name__ == "__main__":
    unittest.main()
