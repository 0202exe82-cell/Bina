"""Проверки персонализации: имя, обращение, «о вас», свой характер, сохранение."""
import tempfile
import unittest
from pathlib import Path

import _stubs  # noqa: F401  (заглушки до импорта engine)
import engine


class PersonalizationTests(unittest.TestCase):
    def setUp(self):
        self.saved = (dict(engine.PERSONAL), engine.LANG, engine.PERSONAL_FILE, engine.PROFILE_FILE,
                      engine.MEMORY_FILE, engine.SETTINGS_FILE)
        tmp = Path(tempfile.mkdtemp())
        engine.PERSONAL_FILE = tmp / "personalization.json"
        engine.PROFILE_FILE = tmp / "profile.txt"
        engine.MEMORY_FILE = tmp / "memory.txt"
        engine.SETTINGS_FILE = tmp / "settings.json"
        for k in engine.PERSONAL:
            engine.PERSONAL[k] = ""
        engine.LANG = "ru"

    def tearDown(self):
        saved_personal, engine.LANG, engine.PERSONAL_FILE, engine.PROFILE_FILE, engine.MEMORY_FILE, \
            engine.SETTINGS_FILE = self.saved
        engine.PERSONAL.update(saved_personal)

    def test_defaults_keep_original_persona(self):
        ru = engine.base_prompt("ru")
        self.assertTrue(ru.startswith("Ты — Бина, ИИ-ассистент. Ты умная"))
        self.assertTrue(engine.base_prompt("en").startswith("You are Bina, an AI assistant."))
        self.assertEqual(ru, engine.SYSTEM_BINA)
        self.assertEqual(engine.base_prompt("en"), engine.SYSTEM_BINA_EN)

    def test_custom_name_changes_prompt_and_english_default_is_transliterated(self):
        engine.set_personal({"name": "Лина"})
        self.assertIn("Ты — Лина", engine.base_prompt("ru"))
        self.assertIn("You are Лина", engine.base_prompt("en"))
        engine.set_personal({"name": ""})
        self.assertEqual((engine.assistant_name("ru"), engine.assistant_name("en")), ("Бина", "Bina"))

    def test_custom_persona_replaces_character_but_keeps_rules(self):
        engine.set_personal({"persona_ru": "Ты строгий, но добрый капитан корабля."})
        p = engine.base_prompt("ru")
        self.assertIn("строгий, но добрый капитан", p)
        self.assertNotIn("холодноватым интеллектом", p)
        self.assertIn("Отвечай по-русски", p)
        self.assertIn("служебная подсказка", p)       # технические правила сохранены
        self.assertIn("холодноватым", engine.base_prompt("en") + "холодноватым")  # английский не затронут
        self.assertIn("coolly intellectual", engine.base_prompt("en"))

    def test_user_name_and_about_reach_system_prompt(self):
        engine.set_personal({"user_name": "Алекс", "about": "Учится на инженера.\nЛюбит шахматы."})
        prompt = engine.Bina().system_prompt()
        self.assertIn("Пользователя зовут Алекс", prompt)
        self.assertIn("Любит шахматы.", prompt)
        engine.LANG = "en"
        self.assertIn("The user's name is Алекс", engine.Bina().system_prompt())

    def test_about_field_overrides_profile_file_and_falls_back_to_it(self):
        engine.PROFILE_FILE.write_text("Факт из profile.txt", encoding="utf-8")
        self.assertEqual(engine.about_text(), "Факт из profile.txt")
        engine.set_personal({"about": "Факт из настроек"})
        self.assertEqual(engine.about_text(), "Факт из настроек")

    def test_values_are_sanitized_and_limited(self):
        engine.set_personal({"name": "Очень\nдлинное   имя " + "x" * 100, "user_name": 123, "about": "a" * 5000})
        self.assertNotIn("\n", engine.PERSONAL["name"])
        self.assertLessEqual(len(engine.PERSONAL["name"]), 30)
        self.assertEqual(engine.PERSONAL["user_name"], "")          # не строка: игнорируется
        self.assertEqual(len(engine.PERSONAL["about"]), 3000)

    def test_roundtrip_and_broken_file(self):
        engine.set_personal({"name": "Лина", "user_name": "Алекс", "persona_en": "You are calm."})
        for k in engine.PERSONAL:
            engine.PERSONAL[k] = ""
        engine.load_personal()
        self.assertEqual((engine.PERSONAL["name"], engine.PERSONAL["user_name"], engine.PERSONAL["persona_en"]),
                         ("Лина", "Алекс", "You are calm."))
        engine.PERSONAL_FILE.write_text("{ не json", encoding="utf-8")
        engine.load_personal()
        self.assertEqual(engine.PERSONAL["name"], "")
        engine.PERSONAL_FILE.write_text('["список вместо объекта"]', encoding="utf-8")
        engine.load_personal()
        self.assertEqual(engine.PERSONAL["about"], "")

    def test_get_personal_provides_placeholders(self):
        info = engine.get_personal()
        self.assertEqual(info["default_name"], "Бина")
        self.assertIn("наблюдательная", info["default_persona_ru"])
        self.assertIn("observant", info["default_persona_en"])


if __name__ == "__main__":
    unittest.main()
