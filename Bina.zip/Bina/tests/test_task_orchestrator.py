import unittest
from unittest.mock import patch

import task_orchestrator as tasks


class TaskOrchestratorTests(unittest.TestCase):
    def test_create_plan_parses_model_json(self):
        response = '{"goal":"найти отчёт", "steps":[{"tool":"files.search","arguments":{"query":"отчёт","max_results":5},"purpose":"Найти файлы отчётов"}]}'
        with patch.object(tasks.bts_dispatcher, "list_tools", return_value=[
            {"name": "files.search", "description": "search", "schema": {
                "query": {"type": "string", "required": True, "max_length": 200},
                "max_results": {"type": "integer", "required": False, "minimum": 1, "maximum": 50}}}
        ]):
            plan = tasks.create_plan("найти отчёт", lambda system, prompt: response)
        self.assertEqual(plan["steps"][0]["tool"], "files.search")

    def test_disallowed_tool_rejected(self):
        with self.assertRaises(tasks.TaskPlanError):
            tasks.validate_plan({"steps": [{"tool": "system.exec", "arguments": {}}]})

    def test_too_many_steps_rejected(self):
        steps = [{"tool": "system.info", "arguments": {}} for _ in range(tasks.MAX_STEPS + 1)]
        with self.assertRaises(tasks.TaskPlanError):
            tasks.validate_plan({"steps": steps})

    def test_arguments_validated_before_execution(self):
        with self.assertRaises(tasks.TaskPlanError):
            tasks.validate_plan({"steps": [{"tool": "files.search", "arguments": {"query": "x", "path": "/"}}]})

    def test_execution_calls_only_validated_steps(self):
        plan = {"goal": "info", "steps": [{"tool": "system.info", "arguments": {}, "purpose": "Информация"}]}
        results = tasks.execute_plan(plan, dispatcher=lambda name, args: "ok")
        self.assertEqual(results[0]["result"], "ok")


if __name__ == "__main__":
    unittest.main()
