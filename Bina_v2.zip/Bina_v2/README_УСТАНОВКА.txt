Бина v2: окно + движок + инструменты (/система, /папки, /файлы).

1. Распакуйте эту папку В НОВОЕ МЕСТО (не поверх старой, у старой bina.py другой).
2. Скопируйте из старой папки свои данные, если есть:
   profile.txt, memory.txt, history.jsonl, topic.json, suggested_topics.json
3. pip install fastapi uvicorn pywebview   (остальное уже стоит)
4. Запуск: start_bina.bat
Папки для поиска файлов: bina_tools_roots.txt (по одной на строку).
