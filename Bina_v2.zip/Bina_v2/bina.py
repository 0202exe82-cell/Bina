"""
Бина: окно приложения. Запуск: py -3.12 bina.py
Требуется: pip install fastapi uvicorn pywebview (плюс то, что стояло для angela.py)
"""
import json
import os
import socket
import threading
import time
import webbrowser
from pathlib import Path

import uvicorn
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, StreamingResponse
from pydantic import BaseModel

import engine

BASE = Path(__file__).parent
app = FastAPI()
lock = threading.Lock()  # один запрос к модели за раз
bina = None


class Msg(BaseModel):
    text: str


@app.get("/")
def index():
    return HTMLResponse((BASE / "index.html").read_text(encoding="utf-8"))


@app.get("/api/start")
def start():
    with lock:
        return {"text": bina.start()}


@app.post("/api/chat")
def chat(msg: Msg):
    def gen():
        with lock:
            try:
                for ev in bina.handle(msg.text):
                    yield json.dumps(ev, ensure_ascii=False) + "\n"
            except Exception as e:
                yield json.dumps({"t": "note", "v": f"[ошибка: {e}]"}, ensure_ascii=False) + "\n"
    return StreamingResponse(gen(), media_type="application/x-ndjson")


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def main():
    global bina
    engine.init_audio()
    bina = engine.Bina()

    port = free_port()
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning"))
    threading.Thread(target=server.run, daemon=True).start()
    while not server.started:
        time.sleep(0.05)
    url = f"http://127.0.0.1:{port}/"

    try:
        import webview
        webview.create_window("Бина", url, width=1000, height=760, min_size=(480, 520))
        webview.start()
    except Exception as e:
        print(f"[окно не открылось ({e}), открываю в браузере; для выхода закройте этот терминал]")
        webbrowser.open(url)
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass
    engine.shutdown_audio()
    os._exit(0)


if __name__ == "__main__":
    main()
