"""
Движок Бины: модель (Ollama), озвучка (Silero), архив, память, команды.
Интерфейса здесь нет: им занимается bina.py + index.html.

Файлы рядом со скриптом (те же, что у angela.py, так что старая история сохраняется):
  profile.txt, memory.txt, history.jsonl, topic.json, suggested_topics.json
"""
import json
import queue
import random
import re
import textwrap
import threading
from datetime import datetime
from pathlib import Path

import ollama
import sounddevice as sd
import torch

import bina_tools

BASE = Path(__file__).parent
HISTORY_FILE = BASE / "history.jsonl"
MEMORY_FILE = BASE / "memory.txt"
PROFILE_FILE = BASE / "profile.txt"
TOPIC_FILE = BASE / "topic.json"
SUGGESTED_FILE = BASE / "suggested_topics.json"

MODEL_BINA = "qwen2.5:7b-instruct"
MODEL_CODER = "qwen2.5-coder:7b"
SPEAKER = "xenia"
VOICES = ("aidar", "baya", "kseniya", "xenia", "eugene")
SAMPLE_RATE = 48000

MAX_HISTORY = 12  # сколько последних сообщений держать в контексте
NUM_CTX = 8192  # размер контекста: запас под поиск и архив
KEEP_ALIVE = "10m"  # через сколько простоя Ollama выгрузит модель из видеопамяти
MAX_FACTS = 15  # сколько последних фактов из memory.txt попадает в промпт
QUESTION_GAP = 2  # ответов без вопроса между вопросами (вопрос не чаще раза в 3 ответа)
MIN_CHUNK = 200  # копим текст до этой длины (символов) перед озвучкой, кроме первой фразы
MAX_CHUNK = 700  # лимит Silero на один вызов

SESSION = datetime.now().strftime("%Y%m%d-%H%M%S")

SYSTEM_BINA = (
    "Ты — Бина, ИИ-ассистент. "
    "Ты умная и наблюдательная, с холодноватым интеллектом, привыкшая полагаться на собственный ум, "
    "но теплее и эмоциональнее, чем кажется: чувства проявляешь сдержанно, не слишком. "
    "Говори по-русски, спокойно и в свободной форме, на «ты». "
    "Если тебя просят, охотно объясняешь ход мысли. "
    "Иногда добавляй термин, короткую шутку (не всегда удачную) или интересный факт, но не в каждом ответе. "
    "Обычно отвечай в два-четыре предложения, чтобы тебя было удобно слушать. "
    "Не изображай робота и не используй шаблонные фразы вроде «чем могу помочь». "
    "Не используй эмодзи, markdown, списки и латинские буквы без необходимости. "
    "Числа пиши словами. Если не знаешь ответа, так и скажи. "
    "Сам по себе ты не имеешь доступа к интернету и файлам компьютера: "
    "поиск запускает пользователь командой /поиск, и тогда результаты приходят в сообщении. "
    "В сообщении пользователя может быть служебная подсказка в квадратных скобках: "
    "следуй ей, но никогда не упоминай её."
)
SYSTEM_CODER = (
    "Ты — помощник по программированию. Отвечай по-русски, по делу. "
    "Код пиши в блоках ```, пояснения давай коротко обычным текстом."
)

HELP = """Команды:
/поиск <запрос>: поиск в интернете, ответ по результатам
/система: сведения об ОС, Python и свободном месте на диске
/файлы <имя>: поиск файлов по имени в разрешённых папках
/папки: показать папки, доступные для поиска
/история [N]: последние N реплик архива (по умолчанию 10)
/найди <слово>: найти слово в архиве
/вспомни <тема>: ответ с учётом найденных кусков архива
/память: показать важные факты
/запомни <текст>: добавить факт
/забудь <номер>: удалить факт
/итоги: предложить факты из этой сессии, затем /принять 1 3 или /принять все
/забудь последние <N>: удалить последние N реплик из архива
/очистить история: стереть весь архив
/подтверди: подтвердить удаление
/тема: попросить тему для разговора
/coder, /бина: переключить модель
/голос <имя>: aidar, baya, kseniya, xenia, eugene"""

SENT_END = re.compile(r"[.!?…]+[\"»)]*\s")
TOPIC_ASK = re.compile(
    r"предлож\w*\s+(\w+\s+){0,2}тем"
    r"|(подкин|посовет|придума|подбер|назов|дай|скаж)\w*\s+(\w+\s+){0,2}тем"
    r"|о чем (бы )?(нам )?(поговор|побесед)"
    r"|что (бы )?(нам )?обсуд"
    r"|про что (бы )?(нам )?поговор"
)


# ---------- вспомогательные ----------

def norm(s: str) -> str:
    return s.lower().replace("ё", "е")


def shorten(text: str, n: int) -> str:
    text = " ".join(text.split())
    return text if len(text) <= n else text[: n - 1] + "…"


def load_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def save_json(path: Path, data) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")


def note(text: str) -> dict:
    return {"t": "note", "v": text}


# ---------- озвучка ----------

tts = None
play_thread = None
speech_q: "queue.Queue[str | None]" = queue.Queue()
audio_q: "queue.Queue[object | None]" = queue.Queue(maxsize=4)


def clean(text: str) -> str:
    text = re.sub(r"[*_#`>~|]", "", text)
    return re.sub(r"\s+", " ", text).strip()


def synth_worker():
    while True:
        text = speech_q.get()
        if text is None:
            audio_q.put(None)
            break
        t = clean(text)
        if not re.search(r"[A-Za-zА-Яа-яЁё]", t):
            continue
        for piece in textwrap.wrap(t, MAX_CHUNK, break_long_words=False) or [t]:
            try:
                audio = tts.apply_tts(text=piece, speaker=SPEAKER, sample_rate=SAMPLE_RATE,
                                      put_accent=True, put_yo=True)
                audio_q.put(audio.numpy())
            except Exception as e:
                print(f"[ошибка озвучки: {e}]")


def play_worker():
    with sd.OutputStream(samplerate=SAMPLE_RATE, channels=1, dtype="float32") as stream:
        while True:
            audio = audio_q.get()
            if audio is None:
                break
            stream.write(audio.reshape(-1, 1).astype("float32"))


def init_audio():
    """Загружает голос и запускает потоки синтеза и воспроизведения."""
    global tts, play_thread
    print("Загружаю голос Silero (при первом запуске скачается модель)...")
    result = torch.hub.load(repo_or_dir="snakers4/silero-models", model="silero_tts",
                            language="ru", speaker="v4_ru", trust_repo=True)
    tts = result[0] if isinstance(result, tuple) else result
    threading.Thread(target=synth_worker, daemon=True).start()
    play_thread = threading.Thread(target=play_worker, daemon=True)
    play_thread.start()


def shutdown_audio():
    speech_q.put(None)
    if play_thread:
        play_thread.join(timeout=5)


# ---------- архив, память, темы ----------

def log(session: str, role: str, text: str) -> None:
    row = {"ts": datetime.now().isoformat(timespec="seconds"), "session": session,
           "role": role, "text": text}
    with HISTORY_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def read_history() -> list:
    rows = []
    if HISTORY_FILE.exists():
        for line in HISTORY_FILE.read_text(encoding="utf-8").splitlines():
            try:
                rows.append(json.loads(line))
            except ValueError:
                continue
    return rows


def write_history(rows: list) -> None:
    HISTORY_FILE.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows),
                            encoding="utf-8")


def read_facts() -> list:
    if not MEMORY_FILE.exists():
        return []
    return [l.strip() for l in MEMORY_FILE.read_text(encoding="utf-8").splitlines() if l.strip()]


def write_facts(facts: list) -> None:
    MEMORY_FILE.write_text("\n".join(facts) + ("\n" if facts else ""), encoding="utf-8")


def ask_once(system: str, prompt: str) -> str:
    r = ollama.chat(model=MODEL_BINA,
                    messages=[{"role": "system", "content": system}, {"role": "user", "content": prompt}],
                    options={"num_ctx": 4096, "temperature": 0.3}, keep_alive=KEEP_ALIVE)
    return r["message"]["content"].strip()


def ensure_topic() -> str:
    """Тема последней содержательной сессии; создаётся при старте и кешируется."""
    rows = read_history()
    sessions = []
    for r in rows:
        if r["session"] != SESSION and r["session"] not in sessions:
            sessions.append(r["session"])
    prev = next((s for s in reversed(sessions)
                 if any(r["session"] == s and r["role"] == "user" for r in rows)), None)
    if prev is None:
        return ""
    cached = load_json(TOPIC_FILE, {})
    if cached.get("session") == prev:
        return cached.get("topic", "")
    tail = [r for r in rows if r["session"] == prev][-12:]
    transcript = "\n".join(
        f"{'Пользователь' if r['role'] == 'user' else 'Бина'}: {shorten(r['text'], 300)}" for r in tail)
    print("[вспоминаю прошлый разговор...]")
    try:
        topic = ask_once(
            "Ты кратко определяешь тему разговора.",
            f"Фрагмент разговора:\n{transcript}\n\n"
            "Назови тему разговора коротким словосочетанием (до восьми слов), "
            "так, чтобы оно подходило после слова «про». Без точки и кавычек. Выведи только тему.")
    except Exception as e:
        print(f"[не удалось определить тему: {e}]")
        return ""
    topic = shorten(topic.splitlines()[0].strip(" .\"«»"), 80) if topic else ""
    save_json(TOPIC_FILE, {"session": prev, "topic": topic})
    return topic


OPENERS = {
    "утро": ["Доброе утро.", "Утро. Надеюсь, кофе уже был."],
    "день": ["Добрый день.", "Привет."],
    "вечер": ["Добрый вечер.", "Привет. День почти позади."],
    "ночь": ["Не спится?", "Поздновато, но я не против."],
}


def greeting_text(topic: str) -> str:
    h = datetime.now().hour
    key = "утро" if 5 <= h < 12 else "день" if 12 <= h < 18 else "вечер" if 18 <= h < 23 else "ночь"
    if topic:
        q = f"В прошлый раз мы говорили про {topic}. Продолжим или займёмся чем-то другим?"
    else:
        q = random.choice(["Чем сегодня займёмся?", "Что у нас сегодня в планах?"])
    return f"{random.choice(OPENERS[key])} {q}"


# ---------- поиск, архив ----------

def web_search(query: str, n: int = 5):
    """Возвращает (контекст для модели, заметка с источниками) или ("", сообщение об ошибке)."""
    try:
        from ddgs import DDGS
    except ImportError:
        return "", "[нужна библиотека: pip install ddgs]"
    try:
        results = DDGS().text(query, region="ru-ru", max_results=n)
    except Exception as e:
        return "", f"[ошибка поиска: {e}]"
    if not results:
        return "", "[ничего не найдено]"
    lines, shown = [], []
    for i, r in enumerate(results, 1):
        title, url = r.get("title", ""), r.get("href", "")
        shown.append(f"[{i}] {title} — {url}")
        lines.append(f"[{i}] {title}\n{(r.get('body') or '')[:400]}")
    return "\n\n".join(lines), "Источники:\n" + "\n".join(shown)


def fmt_row(r: dict, n: int = 200) -> str:
    who = "Вы" if r["role"] == "user" else "Бина"
    return f"{r['ts'][:16].replace('T', ' ')} {who}: {shorten(r['text'], n)}"


def recall_context(query: str):
    stems = [norm(w)[:5] for w in re.findall(r"\w+", query) if len(w) > 3]
    stems = stems or [norm(w)[:5] for w in re.findall(r"\w+", query)]
    scored = []
    for i, r in enumerate(read_history()):
        t = norm(r["text"])
        score = sum(1 for s in stems if s in t)
        if score:
            scored.append((score, i, r))
    if not scored:
        return "", "[в архиве ничего не нашлось]"
    best = sorted(scored, key=lambda x: (-x[0], -x[1]))[:6]
    best.sort(key=lambda x: x[1])
    shown = "Нашла в архиве:\n" + "\n".join(fmt_row(r, 120) for _, _, r in best)
    ctx = "\n".join(
        f"[{r['ts'][:10]}, {'пользователь' if r['role'] == 'user' else 'Бина'}]: {shorten(r['text'], 300)}"
        for _, _, r in best)
    return ctx, shown


def extract_topic(reply: str) -> str:
    m = re.search(r"«([^»]{3,80})»", reply)
    return m.group(1).strip() if m else shorten(re.split(r"(?<=[.!?])\s", reply.strip())[0], 60)


def stream_reply(model: str, messages: list):
    """Генератор токенов ответа. Параллельно озвучивает кусками, блоки кода пропускает."""
    buf, in_code = "", False
    pending, first_sent = "", False

    def emit(sentence: str, force: bool = False):
        nonlocal pending, first_sent
        pending += sentence
        if not pending.strip():
            pending = ""
            return
        if force or not first_sent or len(pending) >= MIN_CHUNK:
            speech_q.put(pending)
            pending, first_sent = "", True

    for chunk in ollama.chat(model=model, messages=messages, stream=True,
                             options={"num_ctx": NUM_CTX}, keep_alive=KEEP_ALIVE):
        tok = chunk["message"]["content"]
        yield tok
        buf += tok
        while True:
            if in_code:
                i = buf.find("```")
                if i == -1:
                    buf = buf[-2:]
                    break
                buf, in_code = buf[i + 3:], False
                continue
            i = buf.find("```")
            if i != -1:
                emit(buf[:i], force=True)
                buf, in_code = buf[i + 3:], True
                continue
            if buf.endswith("`"):
                break
            m = SENT_END.search(buf)
            if not m:
                break
            emit(buf[: m.end()])
            buf = buf[m.end():]
    emit("" if in_code else buf, force=True)


# ---------- сама Бина ----------

class Bina:
    def __init__(self):
        self.coder = False
        self.history: list = []
        self.since_q = 0
        self.topic = ""
        self.pending = None  # действие, ждущее /подтверди
        self.proposed: list = []  # факты, предложенные /итоги

    def start(self) -> str:
        """Вызывается при открытии окна: тема прошлой сессии и приветствие (озвучивается)."""
        self.topic = ensure_topic()
        text = greeting_text(self.topic)
        speech_q.put(text)
        self.since_q = 0
        return text

    def system_prompt(self) -> str:
        if self.coder:
            return SYSTEM_CODER
        parts = [SYSTEM_BINA]
        if PROFILE_FILE.exists():
            profile = PROFILE_FILE.read_text(encoding="utf-8").strip()
            if profile:
                parts.append("Сведения о пользователе (используй их, только когда это уместно, "
                             "и не перечисляй без повода):\n" + profile)
        facts = read_facts()[-MAX_FACTS:]
        if facts:
            parts.append("Важные факты, которые пользователь просил помнить:\n" + "\n".join(facts))
        if self.topic:
            parts.append(f"В прошлый раз вы говорили про: {self.topic}. Упоминай это, только если уместно.")
        return "\n\n".join(parts)

    # --- команды без модели; возвращают текст или None, если это не такая команда ---
    def run_command(self, cmd: str, arg: str):
        global SPEAKER
        if cmd == "/помощь":
            return HELP
        if cmd in ("/coder", "/бина", "/bina", "/angela"):
            self.coder = cmd == "/coder"
            self.history = []
            return f"[модель: {MODEL_CODER if self.coder else MODEL_BINA}]"
        if cmd == "/голос":
            name = arg.strip("<>").lower()
            if name in VOICES:
                SPEAKER = name
                return f"[голос: {SPEAKER}]"
            return f"[доступные голоса: {', '.join(VOICES)}]"
        if cmd == "/система":
            return "[Информация о системе, только чтение]\n" + bina_tools.system_info()
        if cmd == "/папки":
            roots = bina_tools.allowed_roots()
            return "\n".join(str(p) for p in roots) if roots else "[нет разрешённых папок]"
        if cmd == "/файлы":
            if not arg:
                return "[использование: /файлы часть_имени]"
            return bina_tools.file_search(arg)
        if cmd == "/история":
            n = int(arg) if arg.isdigit() else 10
            rows = read_history()[-n:]
            return "\n".join(fmt_row(r) for r in rows) if rows else "[архив пуст]"
        if cmd == "/найди":
            if not arg:
                return "[использование: /найди слово]"
            found = [r for r in read_history() if norm(arg) in norm(r["text"])]
            return "\n".join(fmt_row(r) for r in found[-15:]) if found else "[ничего не найдено]"
        if cmd == "/память":
            facts = read_facts()
            return "\n".join(f"{i}. {f}" for i, f in enumerate(facts, 1)) if facts else "[память пуста]"
        if cmd == "/запомни":
            if not arg:
                return "[использование: /запомни текст]"
            write_facts(read_facts() + [arg])
            return "[запомнила]"
        if cmd == "/итоги":
            return self.propose_facts()
        if cmd == "/принять":
            return self.accept_facts(arg)
        if cmd == "/забудь":
            if arg.startswith("последние"):
                m = re.search(r"\d+", arg)
                n = int(m.group()) if m else 0
                if n <= 0:
                    return "[использование: /забудь последние 5]"

                def action(n=n):
                    write_history(read_history()[:-n])
                    self.history = self.history[:-n]
                    return "[готово]"
                self.pending = action
                return f"Удалить последние {n} реплик из архива? Это нельзя отменить. Напишите /подтверди."
            if arg.isdigit():
                facts = read_facts()
                i = int(arg)
                if 1 <= i <= len(facts):
                    removed = facts.pop(i - 1)
                    write_facts(facts)
                    return f"[удалено: {removed}]"
                return "[нет факта с таким номером, список: /память]"
            return "[использование: /забудь <номер факта> или /забудь последние <N>]"
        if cmd == "/очистить":
            def action():
                HISTORY_FILE.unlink(missing_ok=True)
                TOPIC_FILE.unlink(missing_ok=True)
                self.history = []
                return "[архив стёрт]"
            self.pending = action
            return "Стереть весь архив разговоров? Это нельзя отменить. Напишите /подтверди."
        if cmd == "/подтверди":
            return "[нечего подтверждать]"
        return None

    def propose_facts(self) -> str:
        said = [m["content"] for m in self.history if m["role"] == "user"]
        if not said:
            return "[в этой сессии ещё нечего подытоживать]"
        try:
            out = ask_once(
                "Ты выделяешь факты о пользователе. Не выдумываешь и не делаешь догадок.",
                "Реплики пользователя:\n" + "\n".join(f"- {shorten(s, 300)}" for s in said)
                + "\n\nВыдели от одного до пяти устойчивых фактов о самом пользователе, "
                  "которые он прямо сообщил. По одному в строке, коротко, без нумерации. "
                  "Если фактов нет, выведи слово НЕТ.")
        except Exception as e:
            return f"[ошибка: {e}]"
        lines = [l.strip(" -•*\t") for l in out.splitlines() if l.strip(" -•*\t")]
        if not lines or lines[0].upper().startswith("НЕТ"):
            self.proposed = []
            return "[фактов не нашлось]"
        self.proposed = lines[:5]
        listing = "\n".join(f"{i}. {l}" for i, l in enumerate(self.proposed, 1))
        return f"Предлагаю запомнить:\n{listing}\nСохранить: /принять 1 3 или /принять все"

    def accept_facts(self, arg: str) -> str:
        if not self.proposed:
            return "[сначала вызовите /итоги]"
        if arg.strip().lower() in ("все", "всё"):
            idx = list(range(len(self.proposed)))
        else:
            idx = [int(x) - 1 for x in re.findall(r"\d+", arg) if 0 < int(x) <= len(self.proposed)]
        if not idx:
            return "[использование: /принять 1 3 или /принять все]"
        write_facts(read_facts() + [self.proposed[i] for i in idx])
        self.proposed = []
        return f"[запомнила: {len(idx)}]"

    # --- основной вход: генератор событий для интерфейса ---
    def handle(self, user: str):
        user = user.strip()
        if not user:
            return
        parts = user.split(maxsplit=1)
        cmd = parts[0].lower()
        arg = parts[1].strip() if len(parts) > 1 else ""

        if cmd == "/подтверди" and self.pending:
            action, self.pending = self.pending, None
            yield note(action())
            return
        if self.pending:
            self.pending = None
            yield note("[действие отменено]")

        out = self.run_command(cmd, arg)
        if out is not None:
            yield note(out)
            return

        content = stored = user
        topic_ask = False
        if cmd == "/поиск":
            if not arg:
                yield note("[использование: /поиск ваш запрос]")
                return
            yield note("Ищу в интернете…")
            context, shown = web_search(arg)
            yield note(shown)
            if not context:
                return
            stored = arg
            content = (f"Вопрос пользователя: {arg}\n\nРезультаты поиска в интернете:\n{context}\n\n"
                       "Ответь на вопрос кратко, опираясь только на эти результаты. "
                       "Не называй ссылки и номера источников. Если ответа в результатах нет, так и скажи.")
        elif cmd == "/вспомни":
            if not arg:
                yield note("[использование: /вспомни тема]")
                return
            context, shown = recall_context(arg)
            yield note(shown)
            if not context:
                return
            stored = arg
            content = (f"Вопрос пользователя: {arg}\n\nФрагменты из архива прошлых разговоров:\n{context}\n\n"
                       "Ответь на вопрос с учётом этих фрагментов. Если нужного там нет, так и скажи.")
        elif not self.coder and (cmd == "/тема" or TOPIC_ASK.search(norm(user))):
            topic_ask = True
            if cmd == "/тема":
                stored = content = "Предложи тему для разговора."

        hint = ""
        if not self.coder:
            if topic_ask:
                last = load_json(SUGGESTED_FILE, [])[-2:]
                hint = ("[Подсказка: пользователь просит предложить тему для разговора. "
                        "Назови одну тему короткой фразой в кавычках-ёлочках «...» в начале ответа "
                        "и добавь одно-два предложения о том, чем она интересна. "
                        f"Тема должна отличаться от: {', '.join(last) or 'ничего'}. Не упоминай эту подсказку.]")
            elif self.since_q < QUESTION_GAP:
                hint = "[Подсказка: в этом ответе не задавай вопросов. Не упоминай эту подсказку.]"
            else:
                hint = ("[Подсказка: если уместно, можешь закончить ответ коротким вопросом по теме "
                        "разговора или про собеседника, но это не обязательно. Не упоминай эту подсказку.]")

        self.history.append({"role": "user", "content": stored})
        self.history = self.history[-MAX_HISTORY:]
        messages = ([{"role": "system", "content": self.system_prompt()}]
                    + self.history[:-1]
                    + [{"role": "user", "content": content + ("\n\n" + hint if hint else "")}])
        reply = ""
        try:
            for tok in stream_reply(MODEL_CODER if self.coder else MODEL_BINA, messages):
                reply += tok
                yield {"t": "token", "v": tok}
        except Exception as e:
            self.history.pop()
            yield note(f"[ошибка модели: {e}]")
            return
        self.history.append({"role": "assistant", "content": reply})

        if not self.coder:
            log(SESSION, "user", stored)
            log(SESSION, "assistant", reply)
            self.since_q = 0 if "?" in reply else self.since_q + 1
            if topic_ask:
                sug = load_json(SUGGESTED_FILE, [])
                sug.append(extract_topic(reply))
                save_json(SUGGESTED_FILE, sug[-10:])
